package xtext.robocode.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import xtext.robocode.services.GeneratorGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGeneratorParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_NUMBER", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Arena'", "'{'", "'robot'", "','", "'}'", "'Robot'", "'eventsHandled'", "'('", "')'", "'runActions'", "'infiniteLoopActions'", "'Event'", "'eventType'", "'actions'", "'.'", "'()'", "'%'", "'Action'", "'comment'", "'setter'", "'getter'", "'functionName'", "'parameters'", "'conditions'", "'Condition'", "'identifier'", "'operator'", "'<'", "'>'", "'='", "'<='", "'>='", "'!='", "'=='", "'value'", "'last'", "'AdvancedRobot'", "'RangeControlRobot'", "'BulletHit'", "'BulletMissed'", "'Death'", "'HitByBullet'", "'HitRobot'", "'HitWall'", "'ScannedRobot'", "'Win'", "'Custom'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=7;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int RULE_NUMBER=6;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalGeneratorParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGeneratorParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGeneratorParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGenerator.g"; }



     	private GeneratorGrammarAccess grammarAccess;

        public InternalGeneratorParser(TokenStream input, GeneratorGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Arena";
       	}

       	@Override
       	protected GeneratorGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleArena"
    // InternalGenerator.g:65:1: entryRuleArena returns [EObject current=null] : iv_ruleArena= ruleArena EOF ;
    public final EObject entryRuleArena() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArena = null;


        try {
            // InternalGenerator.g:65:46: (iv_ruleArena= ruleArena EOF )
            // InternalGenerator.g:66:2: iv_ruleArena= ruleArena EOF
            {
             newCompositeNode(grammarAccess.getArenaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArena=ruleArena();

            state._fsp--;

             current =iv_ruleArena; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArena"


    // $ANTLR start "ruleArena"
    // InternalGenerator.g:72:1: ruleArena returns [EObject current=null] : (otherlv_0= 'Arena' otherlv_1= '{' (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )? otherlv_8= '}' ) ;
    public final EObject ruleArena() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        EObject lv_robot_4_0 = null;

        EObject lv_robot_6_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:78:2: ( (otherlv_0= 'Arena' otherlv_1= '{' (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )? otherlv_8= '}' ) )
            // InternalGenerator.g:79:2: (otherlv_0= 'Arena' otherlv_1= '{' (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )? otherlv_8= '}' )
            {
            // InternalGenerator.g:79:2: (otherlv_0= 'Arena' otherlv_1= '{' (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )? otherlv_8= '}' )
            // InternalGenerator.g:80:3: otherlv_0= 'Arena' otherlv_1= '{' (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )? otherlv_8= '}'
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getArenaAccess().getArenaKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getArenaAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalGenerator.g:88:3: (otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalGenerator.g:89:4: otherlv_2= 'robot' otherlv_3= '{' ( (lv_robot_4_0= ruleRobot ) ) (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )* otherlv_7= '}'
                    {
                    otherlv_2=(Token)match(input,14,FOLLOW_3); 

                    				newLeafNode(otherlv_2, grammarAccess.getArenaAccess().getRobotKeyword_2_0());
                    			
                    otherlv_3=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getArenaAccess().getLeftCurlyBracketKeyword_2_1());
                    			
                    // InternalGenerator.g:97:4: ( (lv_robot_4_0= ruleRobot ) )
                    // InternalGenerator.g:98:5: (lv_robot_4_0= ruleRobot )
                    {
                    // InternalGenerator.g:98:5: (lv_robot_4_0= ruleRobot )
                    // InternalGenerator.g:99:6: lv_robot_4_0= ruleRobot
                    {

                    						newCompositeNode(grammarAccess.getArenaAccess().getRobotRobotParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_robot_4_0=ruleRobot();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArenaRule());
                    						}
                    						add(
                    							current,
                    							"robot",
                    							lv_robot_4_0,
                    							"xtext.robocode.Generator.Robot");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:116:4: (otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==15) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalGenerator.g:117:5: otherlv_5= ',' ( (lv_robot_6_0= ruleRobot ) )
                    	    {
                    	    otherlv_5=(Token)match(input,15,FOLLOW_5); 

                    	    					newLeafNode(otherlv_5, grammarAccess.getArenaAccess().getCommaKeyword_2_3_0());
                    	    				
                    	    // InternalGenerator.g:121:5: ( (lv_robot_6_0= ruleRobot ) )
                    	    // InternalGenerator.g:122:6: (lv_robot_6_0= ruleRobot )
                    	    {
                    	    // InternalGenerator.g:122:6: (lv_robot_6_0= ruleRobot )
                    	    // InternalGenerator.g:123:7: lv_robot_6_0= ruleRobot
                    	    {

                    	    							newCompositeNode(grammarAccess.getArenaAccess().getRobotRobotParserRuleCall_2_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_robot_6_0=ruleRobot();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getArenaRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"robot",
                    	    								lv_robot_6_0,
                    	    								"xtext.robocode.Generator.Robot");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_7=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_7, grammarAccess.getArenaAccess().getRightCurlyBracketKeyword_2_4());
                    			

                    }
                    break;

            }

            otherlv_8=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getArenaAccess().getRightCurlyBracketKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArena"


    // $ANTLR start "entryRuleRobot"
    // InternalGenerator.g:154:1: entryRuleRobot returns [EObject current=null] : iv_ruleRobot= ruleRobot EOF ;
    public final EObject entryRuleRobot() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRobot = null;


        try {
            // InternalGenerator.g:154:46: (iv_ruleRobot= ruleRobot EOF )
            // InternalGenerator.g:155:2: iv_ruleRobot= ruleRobot EOF
            {
             newCompositeNode(grammarAccess.getRobotRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRobot=ruleRobot();

            state._fsp--;

             current =iv_ruleRobot; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRobot"


    // $ANTLR start "ruleRobot"
    // InternalGenerator.g:161:1: ruleRobot returns [EObject current=null] : (this_Robot_Impl_0= ruleRobot_Impl | this_AdvancedRobot_Impl_1= ruleAdvancedRobot_Impl | this_RangeControlRobot_2= ruleRangeControlRobot ) ;
    public final EObject ruleRobot() throws RecognitionException {
        EObject current = null;

        EObject this_Robot_Impl_0 = null;

        EObject this_AdvancedRobot_Impl_1 = null;

        EObject this_RangeControlRobot_2 = null;



        	enterRule();

        try {
            // InternalGenerator.g:167:2: ( (this_Robot_Impl_0= ruleRobot_Impl | this_AdvancedRobot_Impl_1= ruleAdvancedRobot_Impl | this_RangeControlRobot_2= ruleRangeControlRobot ) )
            // InternalGenerator.g:168:2: (this_Robot_Impl_0= ruleRobot_Impl | this_AdvancedRobot_Impl_1= ruleAdvancedRobot_Impl | this_RangeControlRobot_2= ruleRangeControlRobot )
            {
            // InternalGenerator.g:168:2: (this_Robot_Impl_0= ruleRobot_Impl | this_AdvancedRobot_Impl_1= ruleAdvancedRobot_Impl | this_RangeControlRobot_2= ruleRangeControlRobot )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt3=1;
                }
                break;
            case 48:
                {
                alt3=2;
                }
                break;
            case 49:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalGenerator.g:169:3: this_Robot_Impl_0= ruleRobot_Impl
                    {

                    			newCompositeNode(grammarAccess.getRobotAccess().getRobot_ImplParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Robot_Impl_0=ruleRobot_Impl();

                    state._fsp--;


                    			current = this_Robot_Impl_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalGenerator.g:178:3: this_AdvancedRobot_Impl_1= ruleAdvancedRobot_Impl
                    {

                    			newCompositeNode(grammarAccess.getRobotAccess().getAdvancedRobot_ImplParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_AdvancedRobot_Impl_1=ruleAdvancedRobot_Impl();

                    state._fsp--;


                    			current = this_AdvancedRobot_Impl_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalGenerator.g:187:3: this_RangeControlRobot_2= ruleRangeControlRobot
                    {

                    			newCompositeNode(grammarAccess.getRobotAccess().getRangeControlRobotParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_RangeControlRobot_2=ruleRangeControlRobot();

                    state._fsp--;


                    			current = this_RangeControlRobot_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRobot"


    // $ANTLR start "entryRuleRobot_Impl"
    // InternalGenerator.g:199:1: entryRuleRobot_Impl returns [EObject current=null] : iv_ruleRobot_Impl= ruleRobot_Impl EOF ;
    public final EObject entryRuleRobot_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRobot_Impl = null;


        try {
            // InternalGenerator.g:199:51: (iv_ruleRobot_Impl= ruleRobot_Impl EOF )
            // InternalGenerator.g:200:2: iv_ruleRobot_Impl= ruleRobot_Impl EOF
            {
             newCompositeNode(grammarAccess.getRobot_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRobot_Impl=ruleRobot_Impl();

            state._fsp--;

             current =iv_ruleRobot_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRobot_Impl"


    // $ANTLR start "ruleRobot_Impl"
    // InternalGenerator.g:206:1: ruleRobot_Impl returns [EObject current=null] : ( () otherlv_1= 'Robot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) ;
    public final EObject ruleRobot_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_eventsHandled_6_0 = null;

        EObject lv_eventsHandled_8_0 = null;

        EObject lv_runActions_12_0 = null;

        EObject lv_runActions_14_0 = null;

        EObject lv_infiniteLoopActions_18_0 = null;

        EObject lv_infiniteLoopActions_20_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:212:2: ( ( () otherlv_1= 'Robot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) )
            // InternalGenerator.g:213:2: ( () otherlv_1= 'Robot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            {
            // InternalGenerator.g:213:2: ( () otherlv_1= 'Robot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            // InternalGenerator.g:214:3: () otherlv_1= 'Robot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}'
            {
            // InternalGenerator.g:214:3: ()
            // InternalGenerator.g:215:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getRobot_ImplAccess().getRobotAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,17,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getRobot_ImplAccess().getRobotKeyword_1());
            		
            // InternalGenerator.g:225:3: ( (lv_name_2_0= ruleEString ) )
            // InternalGenerator.g:226:4: (lv_name_2_0= ruleEString )
            {
            // InternalGenerator.g:226:4: (lv_name_2_0= ruleEString )
            // InternalGenerator.g:227:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getRobot_ImplAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"xtext.robocode.Generator.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_9); 

            			newLeafNode(otherlv_3, grammarAccess.getRobot_ImplAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalGenerator.g:248:3: (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==18) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalGenerator.g:249:4: otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')'
                    {
                    otherlv_4=(Token)match(input,18,FOLLOW_10); 

                    				newLeafNode(otherlv_4, grammarAccess.getRobot_ImplAccess().getEventsHandledKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,19,FOLLOW_11); 

                    				newLeafNode(otherlv_5, grammarAccess.getRobot_ImplAccess().getLeftParenthesisKeyword_4_1());
                    			
                    // InternalGenerator.g:257:4: ( (lv_eventsHandled_6_0= ruleEvent ) )
                    // InternalGenerator.g:258:5: (lv_eventsHandled_6_0= ruleEvent )
                    {
                    // InternalGenerator.g:258:5: (lv_eventsHandled_6_0= ruleEvent )
                    // InternalGenerator.g:259:6: lv_eventsHandled_6_0= ruleEvent
                    {

                    						newCompositeNode(grammarAccess.getRobot_ImplAccess().getEventsHandledEventParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_eventsHandled_6_0=ruleEvent();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"eventsHandled",
                    							lv_eventsHandled_6_0,
                    							"xtext.robocode.Generator.Event");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:276:4: (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==15) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalGenerator.g:277:5: otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    {
                    	    otherlv_7=(Token)match(input,15,FOLLOW_11); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getRobot_ImplAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalGenerator.g:281:5: ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    // InternalGenerator.g:282:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    {
                    	    // InternalGenerator.g:282:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    // InternalGenerator.g:283:7: lv_eventsHandled_8_0= ruleEvent
                    	    {

                    	    							newCompositeNode(grammarAccess.getRobot_ImplAccess().getEventsHandledEventParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_12);
                    	    lv_eventsHandled_8_0=ruleEvent();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"eventsHandled",
                    	    								lv_eventsHandled_8_0,
                    	    								"xtext.robocode.Generator.Event");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,20,FOLLOW_13); 

                    				newLeafNode(otherlv_9, grammarAccess.getRobot_ImplAccess().getRightParenthesisKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:306:3: (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==21) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalGenerator.g:307:4: otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,21,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getRobot_ImplAccess().getRunActionsKeyword_5_0());
                    			
                    otherlv_11=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_11, grammarAccess.getRobot_ImplAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalGenerator.g:315:4: ( (lv_runActions_12_0= ruleAction ) )
                    // InternalGenerator.g:316:5: (lv_runActions_12_0= ruleAction )
                    {
                    // InternalGenerator.g:316:5: (lv_runActions_12_0= ruleAction )
                    // InternalGenerator.g:317:6: lv_runActions_12_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getRobot_ImplAccess().getRunActionsActionParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_runActions_12_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"runActions",
                    							lv_runActions_12_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:334:4: (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )*
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==15) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // InternalGenerator.g:335:5: otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) )
                    	    {
                    	    otherlv_13=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getRobot_ImplAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalGenerator.g:339:5: ( (lv_runActions_14_0= ruleAction ) )
                    	    // InternalGenerator.g:340:6: (lv_runActions_14_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:340:6: (lv_runActions_14_0= ruleAction )
                    	    // InternalGenerator.g:341:7: lv_runActions_14_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getRobot_ImplAccess().getRunActionsActionParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_runActions_14_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"runActions",
                    	    								lv_runActions_14_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop6;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,16,FOLLOW_15); 

                    				newLeafNode(otherlv_15, grammarAccess.getRobot_ImplAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:364:3: (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalGenerator.g:365:4: otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}'
                    {
                    otherlv_16=(Token)match(input,22,FOLLOW_3); 

                    				newLeafNode(otherlv_16, grammarAccess.getRobot_ImplAccess().getInfiniteLoopActionsKeyword_6_0());
                    			
                    otherlv_17=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_17, grammarAccess.getRobot_ImplAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGenerator.g:373:4: ( (lv_infiniteLoopActions_18_0= ruleAction ) )
                    // InternalGenerator.g:374:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    {
                    // InternalGenerator.g:374:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    // InternalGenerator.g:375:6: lv_infiniteLoopActions_18_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getRobot_ImplAccess().getInfiniteLoopActionsActionParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_infiniteLoopActions_18_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"infiniteLoopActions",
                    							lv_infiniteLoopActions_18_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:392:4: (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )*
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( (LA8_0==15) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalGenerator.g:393:5: otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    {
                    	    otherlv_19=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_19, grammarAccess.getRobot_ImplAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGenerator.g:397:5: ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    // InternalGenerator.g:398:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:398:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    // InternalGenerator.g:399:7: lv_infiniteLoopActions_20_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getRobot_ImplAccess().getInfiniteLoopActionsActionParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_infiniteLoopActions_20_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"infiniteLoopActions",
                    	    								lv_infiniteLoopActions_20_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop8;
                        }
                    } while (true);

                    otherlv_21=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_21, grammarAccess.getRobot_ImplAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_22=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_22, grammarAccess.getRobot_ImplAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRobot_Impl"


    // $ANTLR start "entryRuleEvent"
    // InternalGenerator.g:430:1: entryRuleEvent returns [EObject current=null] : iv_ruleEvent= ruleEvent EOF ;
    public final EObject entryRuleEvent() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEvent = null;


        try {
            // InternalGenerator.g:430:46: (iv_ruleEvent= ruleEvent EOF )
            // InternalGenerator.g:431:2: iv_ruleEvent= ruleEvent EOF
            {
             newCompositeNode(grammarAccess.getEventRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEvent=ruleEvent();

            state._fsp--;

             current =iv_ruleEvent; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalGenerator.g:437:1: ruleEvent returns [EObject current=null] : ( () otherlv_1= 'Event' otherlv_2= '{' (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )? (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )? otherlv_11= '}' ) ;
    public final EObject ruleEvent() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Enumerator lv_eventType_4_0 = null;

        EObject lv_actions_7_0 = null;

        EObject lv_actions_9_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:443:2: ( ( () otherlv_1= 'Event' otherlv_2= '{' (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )? (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )? otherlv_11= '}' ) )
            // InternalGenerator.g:444:2: ( () otherlv_1= 'Event' otherlv_2= '{' (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )? (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )? otherlv_11= '}' )
            {
            // InternalGenerator.g:444:2: ( () otherlv_1= 'Event' otherlv_2= '{' (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )? (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )? otherlv_11= '}' )
            // InternalGenerator.g:445:3: () otherlv_1= 'Event' otherlv_2= '{' (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )? (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )? otherlv_11= '}'
            {
            // InternalGenerator.g:445:3: ()
            // InternalGenerator.g:446:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getEventAccess().getEventAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,23,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getEventAccess().getEventKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_16); 

            			newLeafNode(otherlv_2, grammarAccess.getEventAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalGenerator.g:460:3: (otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==24) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalGenerator.g:461:4: otherlv_3= 'eventType' ( (lv_eventType_4_0= ruleEventType ) )
                    {
                    otherlv_3=(Token)match(input,24,FOLLOW_17); 

                    				newLeafNode(otherlv_3, grammarAccess.getEventAccess().getEventTypeKeyword_3_0());
                    			
                    // InternalGenerator.g:465:4: ( (lv_eventType_4_0= ruleEventType ) )
                    // InternalGenerator.g:466:5: (lv_eventType_4_0= ruleEventType )
                    {
                    // InternalGenerator.g:466:5: (lv_eventType_4_0= ruleEventType )
                    // InternalGenerator.g:467:6: lv_eventType_4_0= ruleEventType
                    {

                    						newCompositeNode(grammarAccess.getEventAccess().getEventTypeEventTypeEnumRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_eventType_4_0=ruleEventType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEventRule());
                    						}
                    						set(
                    							current,
                    							"eventType",
                    							lv_eventType_4_0,
                    							"xtext.robocode.Generator.EventType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGenerator.g:485:3: (otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}' )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==25) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalGenerator.g:486:4: otherlv_5= 'actions' otherlv_6= '{' ( (lv_actions_7_0= ruleAction ) ) (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,25,FOLLOW_3); 

                    				newLeafNode(otherlv_5, grammarAccess.getEventAccess().getActionsKeyword_4_0());
                    			
                    otherlv_6=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_6, grammarAccess.getEventAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalGenerator.g:494:4: ( (lv_actions_7_0= ruleAction ) )
                    // InternalGenerator.g:495:5: (lv_actions_7_0= ruleAction )
                    {
                    // InternalGenerator.g:495:5: (lv_actions_7_0= ruleAction )
                    // InternalGenerator.g:496:6: lv_actions_7_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getEventAccess().getActionsActionParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_actions_7_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEventRule());
                    						}
                    						add(
                    							current,
                    							"actions",
                    							lv_actions_7_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:513:4: (otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) ) )*
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( (LA11_0==15) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // InternalGenerator.g:514:5: otherlv_8= ',' ( (lv_actions_9_0= ruleAction ) )
                    	    {
                    	    otherlv_8=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getEventAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalGenerator.g:518:5: ( (lv_actions_9_0= ruleAction ) )
                    	    // InternalGenerator.g:519:6: (lv_actions_9_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:519:6: (lv_actions_9_0= ruleAction )
                    	    // InternalGenerator.g:520:7: lv_actions_9_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getEventAccess().getActionsActionParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_actions_9_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getEventRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"actions",
                    	    								lv_actions_9_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop11;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_10, grammarAccess.getEventAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_11=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getEventAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleEString"
    // InternalGenerator.g:551:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalGenerator.g:551:47: (iv_ruleEString= ruleEString EOF )
            // InternalGenerator.g:552:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalGenerator.g:558:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )? (kw= '()' )? ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;
        Token kw=null;
        Token this_STRING_3=null;
        Token this_ID_4=null;


        	enterRule();

        try {
            // InternalGenerator.g:564:2: ( ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )? (kw= '()' )? ) )
            // InternalGenerator.g:565:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )? (kw= '()' )? )
            {
            // InternalGenerator.g:565:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )? (kw= '()' )? )
            // InternalGenerator.g:566:3: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )? (kw= '()' )?
            {
            // InternalGenerator.g:566:3: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==RULE_STRING) ) {
                alt13=1;
            }
            else if ( (LA13_0==RULE_ID) ) {
                alt13=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalGenerator.g:567:4: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_19); 

                    				current.merge(this_STRING_0);
                    			

                    				newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalGenerator.g:575:4: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_19); 

                    				current.merge(this_ID_1);
                    			

                    				newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_0_1());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:583:3: (kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==26) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalGenerator.g:584:4: kw= '.' (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID )
                    {
                    kw=(Token)match(input,26,FOLLOW_8); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEStringAccess().getFullStopKeyword_1_0());
                    			
                    // InternalGenerator.g:589:4: (this_STRING_3= RULE_STRING | this_ID_4= RULE_ID )
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==RULE_STRING) ) {
                        alt14=1;
                    }
                    else if ( (LA14_0==RULE_ID) ) {
                        alt14=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 14, 0, input);

                        throw nvae;
                    }
                    switch (alt14) {
                        case 1 :
                            // InternalGenerator.g:590:5: this_STRING_3= RULE_STRING
                            {
                            this_STRING_3=(Token)match(input,RULE_STRING,FOLLOW_20); 

                            					current.merge(this_STRING_3);
                            				

                            					newLeafNode(this_STRING_3, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_1_1_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalGenerator.g:598:5: this_ID_4= RULE_ID
                            {
                            this_ID_4=(Token)match(input,RULE_ID,FOLLOW_20); 

                            					current.merge(this_ID_4);
                            				

                            					newLeafNode(this_ID_4, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1_1_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalGenerator.g:607:3: (kw= '()' )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==27) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalGenerator.g:608:4: kw= '()'
                    {
                    kw=(Token)match(input,27,FOLLOW_2); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEStringAccess().getLeftParenthesisRightParenthesisKeyword_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleOperationString"
    // InternalGenerator.g:618:1: entryRuleOperationString returns [String current=null] : iv_ruleOperationString= ruleOperationString EOF ;
    public final String entryRuleOperationString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleOperationString = null;


        try {
            // InternalGenerator.g:618:55: (iv_ruleOperationString= ruleOperationString EOF )
            // InternalGenerator.g:619:2: iv_ruleOperationString= ruleOperationString EOF
            {
             newCompositeNode(grammarAccess.getOperationStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOperationString=ruleOperationString();

            state._fsp--;

             current =iv_ruleOperationString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOperationString"


    // $ANTLR start "ruleOperationString"
    // InternalGenerator.g:625:1: ruleOperationString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_EString_0= ruleEString kw= '%' this_NUMBER_2= RULE_NUMBER ) ;
    public final AntlrDatatypeRuleToken ruleOperationString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_NUMBER_2=null;
        AntlrDatatypeRuleToken this_EString_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:631:2: ( (this_EString_0= ruleEString kw= '%' this_NUMBER_2= RULE_NUMBER ) )
            // InternalGenerator.g:632:2: (this_EString_0= ruleEString kw= '%' this_NUMBER_2= RULE_NUMBER )
            {
            // InternalGenerator.g:632:2: (this_EString_0= ruleEString kw= '%' this_NUMBER_2= RULE_NUMBER )
            // InternalGenerator.g:633:3: this_EString_0= ruleEString kw= '%' this_NUMBER_2= RULE_NUMBER
            {

            			newCompositeNode(grammarAccess.getOperationStringAccess().getEStringParserRuleCall_0());
            		
            pushFollow(FOLLOW_21);
            this_EString_0=ruleEString();

            state._fsp--;


            			current.merge(this_EString_0);
            		

            			afterParserOrEnumRuleCall();
            		
            kw=(Token)match(input,28,FOLLOW_22); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getOperationStringAccess().getPercentSignKeyword_1());
            		
            this_NUMBER_2=(Token)match(input,RULE_NUMBER,FOLLOW_2); 

            			current.merge(this_NUMBER_2);
            		

            			newLeafNode(this_NUMBER_2, grammarAccess.getOperationStringAccess().getNUMBERTerminalRuleCall_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOperationString"


    // $ANTLR start "entryRuleAction"
    // InternalGenerator.g:659:1: entryRuleAction returns [EObject current=null] : iv_ruleAction= ruleAction EOF ;
    public final EObject entryRuleAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAction = null;


        try {
            // InternalGenerator.g:659:47: (iv_ruleAction= ruleAction EOF )
            // InternalGenerator.g:660:2: iv_ruleAction= ruleAction EOF
            {
             newCompositeNode(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAction=ruleAction();

            state._fsp--;

             current =iv_ruleAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalGenerator.g:666:1: ruleAction returns [EObject current=null] : (otherlv_0= 'Action' otherlv_1= '{' (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )? ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )? otherlv_6= 'functionName' ( (lv_functionName_7_0= ruleEString ) ) (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )? (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )? otherlv_16= '}' ) ;
    public final EObject ruleAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_isSetter_4_0=null;
        Token lv_isGetter_5_0=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token lv_parameters_9_2=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        AntlrDatatypeRuleToken lv_comment_3_0 = null;

        AntlrDatatypeRuleToken lv_functionName_7_0 = null;

        AntlrDatatypeRuleToken lv_parameters_9_1 = null;

        EObject lv_conditions_12_0 = null;

        EObject lv_conditions_14_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:672:2: ( (otherlv_0= 'Action' otherlv_1= '{' (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )? ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )? otherlv_6= 'functionName' ( (lv_functionName_7_0= ruleEString ) ) (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )? (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )? otherlv_16= '}' ) )
            // InternalGenerator.g:673:2: (otherlv_0= 'Action' otherlv_1= '{' (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )? ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )? otherlv_6= 'functionName' ( (lv_functionName_7_0= ruleEString ) ) (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )? (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )? otherlv_16= '}' )
            {
            // InternalGenerator.g:673:2: (otherlv_0= 'Action' otherlv_1= '{' (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )? ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )? otherlv_6= 'functionName' ( (lv_functionName_7_0= ruleEString ) ) (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )? (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )? otherlv_16= '}' )
            // InternalGenerator.g:674:3: otherlv_0= 'Action' otherlv_1= '{' (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )? ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )? otherlv_6= 'functionName' ( (lv_functionName_7_0= ruleEString ) ) (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )? (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )? otherlv_16= '}'
            {
            otherlv_0=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getActionAccess().getActionKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_23); 

            			newLeafNode(otherlv_1, grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalGenerator.g:682:3: (otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==30) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalGenerator.g:683:4: otherlv_2= 'comment' ( (lv_comment_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,30,FOLLOW_8); 

                    				newLeafNode(otherlv_2, grammarAccess.getActionAccess().getCommentKeyword_2_0());
                    			
                    // InternalGenerator.g:687:4: ( (lv_comment_3_0= ruleEString ) )
                    // InternalGenerator.g:688:5: (lv_comment_3_0= ruleEString )
                    {
                    // InternalGenerator.g:688:5: (lv_comment_3_0= ruleEString )
                    // InternalGenerator.g:689:6: lv_comment_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActionAccess().getCommentEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_24);
                    lv_comment_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActionRule());
                    						}
                    						set(
                    							current,
                    							"comment",
                    							lv_comment_3_0,
                    							"xtext.robocode.Generator.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGenerator.g:707:3: ( ( (lv_isSetter_4_0= 'setter' ) ) | ( (lv_isGetter_5_0= 'getter' ) ) )?
            int alt18=3;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==31) ) {
                alt18=1;
            }
            else if ( (LA18_0==32) ) {
                alt18=2;
            }
            switch (alt18) {
                case 1 :
                    // InternalGenerator.g:708:4: ( (lv_isSetter_4_0= 'setter' ) )
                    {
                    // InternalGenerator.g:708:4: ( (lv_isSetter_4_0= 'setter' ) )
                    // InternalGenerator.g:709:5: (lv_isSetter_4_0= 'setter' )
                    {
                    // InternalGenerator.g:709:5: (lv_isSetter_4_0= 'setter' )
                    // InternalGenerator.g:710:6: lv_isSetter_4_0= 'setter'
                    {
                    lv_isSetter_4_0=(Token)match(input,31,FOLLOW_25); 

                    						newLeafNode(lv_isSetter_4_0, grammarAccess.getActionAccess().getIsSetterSetterKeyword_3_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getActionRule());
                    						}
                    						setWithLastConsumed(current, "isSetter", lv_isSetter_4_0 != null, "setter");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalGenerator.g:723:4: ( (lv_isGetter_5_0= 'getter' ) )
                    {
                    // InternalGenerator.g:723:4: ( (lv_isGetter_5_0= 'getter' ) )
                    // InternalGenerator.g:724:5: (lv_isGetter_5_0= 'getter' )
                    {
                    // InternalGenerator.g:724:5: (lv_isGetter_5_0= 'getter' )
                    // InternalGenerator.g:725:6: lv_isGetter_5_0= 'getter'
                    {
                    lv_isGetter_5_0=(Token)match(input,32,FOLLOW_25); 

                    						newLeafNode(lv_isGetter_5_0, grammarAccess.getActionAccess().getIsGetterGetterKeyword_3_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getActionRule());
                    						}
                    						setWithLastConsumed(current, "isGetter", lv_isGetter_5_0 != null, "getter");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_6=(Token)match(input,33,FOLLOW_8); 

            			newLeafNode(otherlv_6, grammarAccess.getActionAccess().getFunctionNameKeyword_4());
            		
            // InternalGenerator.g:742:3: ( (lv_functionName_7_0= ruleEString ) )
            // InternalGenerator.g:743:4: (lv_functionName_7_0= ruleEString )
            {
            // InternalGenerator.g:743:4: (lv_functionName_7_0= ruleEString )
            // InternalGenerator.g:744:5: lv_functionName_7_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getActionAccess().getFunctionNameEStringParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_26);
            lv_functionName_7_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionRule());
            					}
            					set(
            						current,
            						"functionName",
            						lv_functionName_7_0,
            						"xtext.robocode.Generator.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGenerator.g:761:3: (otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==34) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalGenerator.g:762:4: otherlv_8= 'parameters' ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) )
                    {
                    otherlv_8=(Token)match(input,34,FOLLOW_27); 

                    				newLeafNode(otherlv_8, grammarAccess.getActionAccess().getParametersKeyword_6_0());
                    			
                    // InternalGenerator.g:766:4: ( ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) ) )
                    // InternalGenerator.g:767:5: ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) )
                    {
                    // InternalGenerator.g:767:5: ( (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER ) )
                    // InternalGenerator.g:768:6: (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER )
                    {
                    // InternalGenerator.g:768:6: (lv_parameters_9_1= ruleEString | lv_parameters_9_2= RULE_NUMBER )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( ((LA19_0>=RULE_STRING && LA19_0<=RULE_ID)) ) {
                        alt19=1;
                    }
                    else if ( (LA19_0==RULE_NUMBER) ) {
                        alt19=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalGenerator.g:769:7: lv_parameters_9_1= ruleEString
                            {

                            							newCompositeNode(grammarAccess.getActionAccess().getParametersEStringParserRuleCall_6_1_0_0());
                            						
                            pushFollow(FOLLOW_28);
                            lv_parameters_9_1=ruleEString();

                            state._fsp--;


                            							if (current==null) {
                            								current = createModelElementForParent(grammarAccess.getActionRule());
                            							}
                            							set(
                            								current,
                            								"parameters",
                            								lv_parameters_9_1,
                            								"xtext.robocode.Generator.EString");
                            							afterParserOrEnumRuleCall();
                            						

                            }
                            break;
                        case 2 :
                            // InternalGenerator.g:785:7: lv_parameters_9_2= RULE_NUMBER
                            {
                            lv_parameters_9_2=(Token)match(input,RULE_NUMBER,FOLLOW_28); 

                            							newLeafNode(lv_parameters_9_2, grammarAccess.getActionAccess().getParametersNUMBERTerminalRuleCall_6_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getActionRule());
                            							}
                            							setWithLastConsumed(
                            								current,
                            								"parameters",
                            								lv_parameters_9_2,
                            								"xtext.robocode.Generator.NUMBER");
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalGenerator.g:803:3: (otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}' )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==35) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalGenerator.g:804:4: otherlv_10= 'conditions' otherlv_11= '{' ( (lv_conditions_12_0= ruleCondition ) ) (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,35,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getActionAccess().getConditionsKeyword_7_0());
                    			
                    otherlv_11=(Token)match(input,13,FOLLOW_29); 

                    				newLeafNode(otherlv_11, grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_7_1());
                    			
                    // InternalGenerator.g:812:4: ( (lv_conditions_12_0= ruleCondition ) )
                    // InternalGenerator.g:813:5: (lv_conditions_12_0= ruleCondition )
                    {
                    // InternalGenerator.g:813:5: (lv_conditions_12_0= ruleCondition )
                    // InternalGenerator.g:814:6: lv_conditions_12_0= ruleCondition
                    {

                    						newCompositeNode(grammarAccess.getActionAccess().getConditionsConditionParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_conditions_12_0=ruleCondition();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActionRule());
                    						}
                    						add(
                    							current,
                    							"conditions",
                    							lv_conditions_12_0,
                    							"xtext.robocode.Generator.Condition");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:831:4: (otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) ) )*
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==15) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // InternalGenerator.g:832:5: otherlv_13= ',' ( (lv_conditions_14_0= ruleCondition ) )
                    	    {
                    	    otherlv_13=(Token)match(input,15,FOLLOW_29); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getActionAccess().getCommaKeyword_7_3_0());
                    	    				
                    	    // InternalGenerator.g:836:5: ( (lv_conditions_14_0= ruleCondition ) )
                    	    // InternalGenerator.g:837:6: (lv_conditions_14_0= ruleCondition )
                    	    {
                    	    // InternalGenerator.g:837:6: (lv_conditions_14_0= ruleCondition )
                    	    // InternalGenerator.g:838:7: lv_conditions_14_0= ruleCondition
                    	    {

                    	    							newCompositeNode(grammarAccess.getActionAccess().getConditionsConditionParserRuleCall_7_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_conditions_14_0=ruleCondition();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getActionRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"conditions",
                    	    								lv_conditions_14_0,
                    	    								"xtext.robocode.Generator.Condition");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop21;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_15, grammarAccess.getActionAccess().getRightCurlyBracketKeyword_7_4());
                    			

                    }
                    break;

            }

            otherlv_16=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getActionAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleCondition"
    // InternalGenerator.g:869:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalGenerator.g:869:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalGenerator.g:870:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalGenerator.g:876:1: ruleCondition returns [EObject current=null] : (otherlv_0= 'Condition' otherlv_1= '{' otherlv_2= 'identifier' ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) ) (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )? (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )? ( (lv_isLastCondition_8_0= 'last' ) )? otherlv_9= '}' ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token lv_operator_5_1=null;
        Token lv_operator_5_2=null;
        Token lv_operator_5_3=null;
        Token lv_operator_5_4=null;
        Token lv_operator_5_5=null;
        Token lv_operator_5_6=null;
        Token lv_operator_5_7=null;
        Token otherlv_6=null;
        Token lv_value_7_0=null;
        Token lv_isLastCondition_8_0=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_identifier_3_1 = null;

        AntlrDatatypeRuleToken lv_identifier_3_2 = null;



        	enterRule();

        try {
            // InternalGenerator.g:882:2: ( (otherlv_0= 'Condition' otherlv_1= '{' otherlv_2= 'identifier' ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) ) (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )? (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )? ( (lv_isLastCondition_8_0= 'last' ) )? otherlv_9= '}' ) )
            // InternalGenerator.g:883:2: (otherlv_0= 'Condition' otherlv_1= '{' otherlv_2= 'identifier' ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) ) (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )? (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )? ( (lv_isLastCondition_8_0= 'last' ) )? otherlv_9= '}' )
            {
            // InternalGenerator.g:883:2: (otherlv_0= 'Condition' otherlv_1= '{' otherlv_2= 'identifier' ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) ) (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )? (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )? ( (lv_isLastCondition_8_0= 'last' ) )? otherlv_9= '}' )
            // InternalGenerator.g:884:3: otherlv_0= 'Condition' otherlv_1= '{' otherlv_2= 'identifier' ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) ) (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )? (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )? ( (lv_isLastCondition_8_0= 'last' ) )? otherlv_9= '}'
            {
            otherlv_0=(Token)match(input,36,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getConditionAccess().getConditionKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_30); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,37,FOLLOW_8); 

            			newLeafNode(otherlv_2, grammarAccess.getConditionAccess().getIdentifierKeyword_2());
            		
            // InternalGenerator.g:896:3: ( ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) ) )
            // InternalGenerator.g:897:4: ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) )
            {
            // InternalGenerator.g:897:4: ( (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString ) )
            // InternalGenerator.g:898:5: (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString )
            {
            // InternalGenerator.g:898:5: (lv_identifier_3_1= ruleEString | lv_identifier_3_2= ruleOperationString )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==RULE_STRING) ) {
                switch ( input.LA(2) ) {
                case 26:
                    {
                    int LA23_3 = input.LA(3);

                    if ( (LA23_3==RULE_STRING) ) {
                        switch ( input.LA(4) ) {
                        case 27:
                            {
                            int LA23_4 = input.LA(5);

                            if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                                alt23=1;
                            }
                            else if ( (LA23_4==28) ) {
                                alt23=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 16:
                        case 38:
                        case 46:
                        case 47:
                            {
                            alt23=1;
                            }
                            break;
                        case 28:
                            {
                            alt23=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 23, 7, input);

                            throw nvae;
                        }

                    }
                    else if ( (LA23_3==RULE_ID) ) {
                        switch ( input.LA(4) ) {
                        case 27:
                            {
                            int LA23_4 = input.LA(5);

                            if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                                alt23=1;
                            }
                            else if ( (LA23_4==28) ) {
                                alt23=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 28:
                            {
                            alt23=2;
                            }
                            break;
                        case 16:
                        case 38:
                        case 46:
                        case 47:
                            {
                            alt23=1;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 23, 8, input);

                            throw nvae;
                        }

                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 27:
                    {
                    int LA23_4 = input.LA(3);

                    if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                        alt23=1;
                    }
                    else if ( (LA23_4==28) ) {
                        alt23=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 16:
                case 38:
                case 46:
                case 47:
                    {
                    alt23=1;
                    }
                    break;
                case 28:
                    {
                    alt23=2;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 1, input);

                    throw nvae;
                }

            }
            else if ( (LA23_0==RULE_ID) ) {
                switch ( input.LA(2) ) {
                case 26:
                    {
                    int LA23_3 = input.LA(3);

                    if ( (LA23_3==RULE_STRING) ) {
                        switch ( input.LA(4) ) {
                        case 27:
                            {
                            int LA23_4 = input.LA(5);

                            if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                                alt23=1;
                            }
                            else if ( (LA23_4==28) ) {
                                alt23=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 16:
                        case 38:
                        case 46:
                        case 47:
                            {
                            alt23=1;
                            }
                            break;
                        case 28:
                            {
                            alt23=2;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 23, 7, input);

                            throw nvae;
                        }

                    }
                    else if ( (LA23_3==RULE_ID) ) {
                        switch ( input.LA(4) ) {
                        case 27:
                            {
                            int LA23_4 = input.LA(5);

                            if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                                alt23=1;
                            }
                            else if ( (LA23_4==28) ) {
                                alt23=2;
                            }
                            else {
                                NoViableAltException nvae =
                                    new NoViableAltException("", 23, 4, input);

                                throw nvae;
                            }
                            }
                            break;
                        case 28:
                            {
                            alt23=2;
                            }
                            break;
                        case 16:
                        case 38:
                        case 46:
                        case 47:
                            {
                            alt23=1;
                            }
                            break;
                        default:
                            NoViableAltException nvae =
                                new NoViableAltException("", 23, 8, input);

                            throw nvae;
                        }

                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 3, input);

                        throw nvae;
                    }
                    }
                    break;
                case 27:
                    {
                    int LA23_4 = input.LA(3);

                    if ( (LA23_4==16||LA23_4==38||(LA23_4>=46 && LA23_4<=47)) ) {
                        alt23=1;
                    }
                    else if ( (LA23_4==28) ) {
                        alt23=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 23, 4, input);

                        throw nvae;
                    }
                    }
                    break;
                case 16:
                case 38:
                case 46:
                case 47:
                    {
                    alt23=1;
                    }
                    break;
                case 28:
                    {
                    alt23=2;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 23, 2, input);

                    throw nvae;
                }

            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // InternalGenerator.g:899:6: lv_identifier_3_1= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getConditionAccess().getIdentifierEStringParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_31);
                    lv_identifier_3_1=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionRule());
                    						}
                    						set(
                    							current,
                    							"identifier",
                    							lv_identifier_3_1,
                    							"xtext.robocode.Generator.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;
                case 2 :
                    // InternalGenerator.g:915:6: lv_identifier_3_2= ruleOperationString
                    {

                    						newCompositeNode(grammarAccess.getConditionAccess().getIdentifierOperationStringParserRuleCall_3_0_1());
                    					
                    pushFollow(FOLLOW_31);
                    lv_identifier_3_2=ruleOperationString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionRule());
                    						}
                    						set(
                    							current,
                    							"identifier",
                    							lv_identifier_3_2,
                    							"xtext.robocode.Generator.OperationString");
                    						afterParserOrEnumRuleCall();
                    					

                    }
                    break;

            }


            }


            }

            // InternalGenerator.g:933:3: (otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==38) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalGenerator.g:934:4: otherlv_4= 'operator' ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) )
                    {
                    otherlv_4=(Token)match(input,38,FOLLOW_32); 

                    				newLeafNode(otherlv_4, grammarAccess.getConditionAccess().getOperatorKeyword_4_0());
                    			
                    // InternalGenerator.g:938:4: ( ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) ) )
                    // InternalGenerator.g:939:5: ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) )
                    {
                    // InternalGenerator.g:939:5: ( (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' ) )
                    // InternalGenerator.g:940:6: (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' )
                    {
                    // InternalGenerator.g:940:6: (lv_operator_5_1= '<' | lv_operator_5_2= '>' | lv_operator_5_3= '=' | lv_operator_5_4= '<=' | lv_operator_5_5= '>=' | lv_operator_5_6= '!=' | lv_operator_5_7= '==' )
                    int alt24=7;
                    switch ( input.LA(1) ) {
                    case 39:
                        {
                        alt24=1;
                        }
                        break;
                    case 40:
                        {
                        alt24=2;
                        }
                        break;
                    case 41:
                        {
                        alt24=3;
                        }
                        break;
                    case 42:
                        {
                        alt24=4;
                        }
                        break;
                    case 43:
                        {
                        alt24=5;
                        }
                        break;
                    case 44:
                        {
                        alt24=6;
                        }
                        break;
                    case 45:
                        {
                        alt24=7;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 24, 0, input);

                        throw nvae;
                    }

                    switch (alt24) {
                        case 1 :
                            // InternalGenerator.g:941:7: lv_operator_5_1= '<'
                            {
                            lv_operator_5_1=(Token)match(input,39,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_1, grammarAccess.getConditionAccess().getOperatorLessThanSignKeyword_4_1_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_1, null);
                            						

                            }
                            break;
                        case 2 :
                            // InternalGenerator.g:952:7: lv_operator_5_2= '>'
                            {
                            lv_operator_5_2=(Token)match(input,40,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_2, grammarAccess.getConditionAccess().getOperatorGreaterThanSignKeyword_4_1_0_1());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_2, null);
                            						

                            }
                            break;
                        case 3 :
                            // InternalGenerator.g:963:7: lv_operator_5_3= '='
                            {
                            lv_operator_5_3=(Token)match(input,41,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_3, grammarAccess.getConditionAccess().getOperatorEqualsSignKeyword_4_1_0_2());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_3, null);
                            						

                            }
                            break;
                        case 4 :
                            // InternalGenerator.g:974:7: lv_operator_5_4= '<='
                            {
                            lv_operator_5_4=(Token)match(input,42,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_4, grammarAccess.getConditionAccess().getOperatorLessThanSignEqualsSignKeyword_4_1_0_3());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_4, null);
                            						

                            }
                            break;
                        case 5 :
                            // InternalGenerator.g:985:7: lv_operator_5_5= '>='
                            {
                            lv_operator_5_5=(Token)match(input,43,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_5, grammarAccess.getConditionAccess().getOperatorGreaterThanSignEqualsSignKeyword_4_1_0_4());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_5, null);
                            						

                            }
                            break;
                        case 6 :
                            // InternalGenerator.g:996:7: lv_operator_5_6= '!='
                            {
                            lv_operator_5_6=(Token)match(input,44,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_6, grammarAccess.getConditionAccess().getOperatorExclamationMarkEqualsSignKeyword_4_1_0_5());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_6, null);
                            						

                            }
                            break;
                        case 7 :
                            // InternalGenerator.g:1007:7: lv_operator_5_7= '=='
                            {
                            lv_operator_5_7=(Token)match(input,45,FOLLOW_33); 

                            							newLeafNode(lv_operator_5_7, grammarAccess.getConditionAccess().getOperatorEqualsSignEqualsSignKeyword_4_1_0_6());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getConditionRule());
                            							}
                            							setWithLastConsumed(current, "operator", lv_operator_5_7, null);
                            						

                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }

            // InternalGenerator.g:1021:3: (otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) ) )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==46) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalGenerator.g:1022:4: otherlv_6= 'value' ( (lv_value_7_0= RULE_NUMBER ) )
                    {
                    otherlv_6=(Token)match(input,46,FOLLOW_22); 

                    				newLeafNode(otherlv_6, grammarAccess.getConditionAccess().getValueKeyword_5_0());
                    			
                    // InternalGenerator.g:1026:4: ( (lv_value_7_0= RULE_NUMBER ) )
                    // InternalGenerator.g:1027:5: (lv_value_7_0= RULE_NUMBER )
                    {
                    // InternalGenerator.g:1027:5: (lv_value_7_0= RULE_NUMBER )
                    // InternalGenerator.g:1028:6: lv_value_7_0= RULE_NUMBER
                    {
                    lv_value_7_0=(Token)match(input,RULE_NUMBER,FOLLOW_34); 

                    						newLeafNode(lv_value_7_0, grammarAccess.getConditionAccess().getValueNUMBERTerminalRuleCall_5_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConditionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"value",
                    							lv_value_7_0,
                    							"xtext.robocode.Generator.NUMBER");
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGenerator.g:1045:3: ( (lv_isLastCondition_8_0= 'last' ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==47) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalGenerator.g:1046:4: (lv_isLastCondition_8_0= 'last' )
                    {
                    // InternalGenerator.g:1046:4: (lv_isLastCondition_8_0= 'last' )
                    // InternalGenerator.g:1047:5: lv_isLastCondition_8_0= 'last'
                    {
                    lv_isLastCondition_8_0=(Token)match(input,47,FOLLOW_7); 

                    					newLeafNode(lv_isLastCondition_8_0, grammarAccess.getConditionAccess().getIsLastConditionLastKeyword_6_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getConditionRule());
                    					}
                    					setWithLastConsumed(current, "isLastCondition", lv_isLastCondition_8_0 != null, "last");
                    				

                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getConditionAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleAdvancedRobot_Impl"
    // InternalGenerator.g:1067:1: entryRuleAdvancedRobot_Impl returns [EObject current=null] : iv_ruleAdvancedRobot_Impl= ruleAdvancedRobot_Impl EOF ;
    public final EObject entryRuleAdvancedRobot_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAdvancedRobot_Impl = null;


        try {
            // InternalGenerator.g:1067:59: (iv_ruleAdvancedRobot_Impl= ruleAdvancedRobot_Impl EOF )
            // InternalGenerator.g:1068:2: iv_ruleAdvancedRobot_Impl= ruleAdvancedRobot_Impl EOF
            {
             newCompositeNode(grammarAccess.getAdvancedRobot_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAdvancedRobot_Impl=ruleAdvancedRobot_Impl();

            state._fsp--;

             current =iv_ruleAdvancedRobot_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAdvancedRobot_Impl"


    // $ANTLR start "ruleAdvancedRobot_Impl"
    // InternalGenerator.g:1074:1: ruleAdvancedRobot_Impl returns [EObject current=null] : ( () otherlv_1= 'AdvancedRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) ;
    public final EObject ruleAdvancedRobot_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_eventsHandled_6_0 = null;

        EObject lv_eventsHandled_8_0 = null;

        EObject lv_runActions_12_0 = null;

        EObject lv_runActions_14_0 = null;

        EObject lv_infiniteLoopActions_18_0 = null;

        EObject lv_infiniteLoopActions_20_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:1080:2: ( ( () otherlv_1= 'AdvancedRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) )
            // InternalGenerator.g:1081:2: ( () otherlv_1= 'AdvancedRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            {
            // InternalGenerator.g:1081:2: ( () otherlv_1= 'AdvancedRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            // InternalGenerator.g:1082:3: () otherlv_1= 'AdvancedRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}'
            {
            // InternalGenerator.g:1082:3: ()
            // InternalGenerator.g:1083:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getAdvancedRobot_ImplAccess().getAdvancedRobotAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,48,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getAdvancedRobot_ImplAccess().getAdvancedRobotKeyword_1());
            		
            // InternalGenerator.g:1093:3: ( (lv_name_2_0= ruleEString ) )
            // InternalGenerator.g:1094:4: (lv_name_2_0= ruleEString )
            {
            // InternalGenerator.g:1094:4: (lv_name_2_0= ruleEString )
            // InternalGenerator.g:1095:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"xtext.robocode.Generator.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_9); 

            			newLeafNode(otherlv_3, grammarAccess.getAdvancedRobot_ImplAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalGenerator.g:1116:3: (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==18) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalGenerator.g:1117:4: otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')'
                    {
                    otherlv_4=(Token)match(input,18,FOLLOW_10); 

                    				newLeafNode(otherlv_4, grammarAccess.getAdvancedRobot_ImplAccess().getEventsHandledKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,19,FOLLOW_11); 

                    				newLeafNode(otherlv_5, grammarAccess.getAdvancedRobot_ImplAccess().getLeftParenthesisKeyword_4_1());
                    			
                    // InternalGenerator.g:1125:4: ( (lv_eventsHandled_6_0= ruleEvent ) )
                    // InternalGenerator.g:1126:5: (lv_eventsHandled_6_0= ruleEvent )
                    {
                    // InternalGenerator.g:1126:5: (lv_eventsHandled_6_0= ruleEvent )
                    // InternalGenerator.g:1127:6: lv_eventsHandled_6_0= ruleEvent
                    {

                    						newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getEventsHandledEventParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_eventsHandled_6_0=ruleEvent();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"eventsHandled",
                    							lv_eventsHandled_6_0,
                    							"xtext.robocode.Generator.Event");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1144:4: (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )*
                    loop28:
                    do {
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==15) ) {
                            alt28=1;
                        }


                        switch (alt28) {
                    	case 1 :
                    	    // InternalGenerator.g:1145:5: otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    {
                    	    otherlv_7=(Token)match(input,15,FOLLOW_11); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getAdvancedRobot_ImplAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalGenerator.g:1149:5: ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    // InternalGenerator.g:1150:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    {
                    	    // InternalGenerator.g:1150:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    // InternalGenerator.g:1151:7: lv_eventsHandled_8_0= ruleEvent
                    	    {

                    	    							newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getEventsHandledEventParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_12);
                    	    lv_eventsHandled_8_0=ruleEvent();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"eventsHandled",
                    	    								lv_eventsHandled_8_0,
                    	    								"xtext.robocode.Generator.Event");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop28;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,20,FOLLOW_13); 

                    				newLeafNode(otherlv_9, grammarAccess.getAdvancedRobot_ImplAccess().getRightParenthesisKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:1174:3: (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==21) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalGenerator.g:1175:4: otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,21,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getAdvancedRobot_ImplAccess().getRunActionsKeyword_5_0());
                    			
                    otherlv_11=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_11, grammarAccess.getAdvancedRobot_ImplAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalGenerator.g:1183:4: ( (lv_runActions_12_0= ruleAction ) )
                    // InternalGenerator.g:1184:5: (lv_runActions_12_0= ruleAction )
                    {
                    // InternalGenerator.g:1184:5: (lv_runActions_12_0= ruleAction )
                    // InternalGenerator.g:1185:6: lv_runActions_12_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getRunActionsActionParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_runActions_12_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"runActions",
                    							lv_runActions_12_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1202:4: (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )*
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0==15) ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // InternalGenerator.g:1203:5: otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) )
                    	    {
                    	    otherlv_13=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getAdvancedRobot_ImplAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalGenerator.g:1207:5: ( (lv_runActions_14_0= ruleAction ) )
                    	    // InternalGenerator.g:1208:6: (lv_runActions_14_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:1208:6: (lv_runActions_14_0= ruleAction )
                    	    // InternalGenerator.g:1209:7: lv_runActions_14_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getRunActionsActionParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_runActions_14_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"runActions",
                    	    								lv_runActions_14_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop30;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,16,FOLLOW_15); 

                    				newLeafNode(otherlv_15, grammarAccess.getAdvancedRobot_ImplAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:1232:3: (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==22) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalGenerator.g:1233:4: otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}'
                    {
                    otherlv_16=(Token)match(input,22,FOLLOW_3); 

                    				newLeafNode(otherlv_16, grammarAccess.getAdvancedRobot_ImplAccess().getInfiniteLoopActionsKeyword_6_0());
                    			
                    otherlv_17=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_17, grammarAccess.getAdvancedRobot_ImplAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGenerator.g:1241:4: ( (lv_infiniteLoopActions_18_0= ruleAction ) )
                    // InternalGenerator.g:1242:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    {
                    // InternalGenerator.g:1242:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    // InternalGenerator.g:1243:6: lv_infiniteLoopActions_18_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getInfiniteLoopActionsActionParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_infiniteLoopActions_18_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    						}
                    						add(
                    							current,
                    							"infiniteLoopActions",
                    							lv_infiniteLoopActions_18_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1260:4: (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )*
                    loop32:
                    do {
                        int alt32=2;
                        int LA32_0 = input.LA(1);

                        if ( (LA32_0==15) ) {
                            alt32=1;
                        }


                        switch (alt32) {
                    	case 1 :
                    	    // InternalGenerator.g:1261:5: otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    {
                    	    otherlv_19=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_19, grammarAccess.getAdvancedRobot_ImplAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGenerator.g:1265:5: ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    // InternalGenerator.g:1266:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:1266:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    // InternalGenerator.g:1267:7: lv_infiniteLoopActions_20_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getAdvancedRobot_ImplAccess().getInfiniteLoopActionsActionParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_infiniteLoopActions_20_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getAdvancedRobot_ImplRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"infiniteLoopActions",
                    	    								lv_infiniteLoopActions_20_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop32;
                        }
                    } while (true);

                    otherlv_21=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_21, grammarAccess.getAdvancedRobot_ImplAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_22=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_22, grammarAccess.getAdvancedRobot_ImplAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAdvancedRobot_Impl"


    // $ANTLR start "entryRuleRangeControlRobot"
    // InternalGenerator.g:1298:1: entryRuleRangeControlRobot returns [EObject current=null] : iv_ruleRangeControlRobot= ruleRangeControlRobot EOF ;
    public final EObject entryRuleRangeControlRobot() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRangeControlRobot = null;


        try {
            // InternalGenerator.g:1298:58: (iv_ruleRangeControlRobot= ruleRangeControlRobot EOF )
            // InternalGenerator.g:1299:2: iv_ruleRangeControlRobot= ruleRangeControlRobot EOF
            {
             newCompositeNode(grammarAccess.getRangeControlRobotRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRangeControlRobot=ruleRangeControlRobot();

            state._fsp--;

             current =iv_ruleRangeControlRobot; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRangeControlRobot"


    // $ANTLR start "ruleRangeControlRobot"
    // InternalGenerator.g:1305:1: ruleRangeControlRobot returns [EObject current=null] : ( () otherlv_1= 'RangeControlRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) ;
    public final EObject ruleRangeControlRobot() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_22=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        EObject lv_eventsHandled_6_0 = null;

        EObject lv_eventsHandled_8_0 = null;

        EObject lv_runActions_12_0 = null;

        EObject lv_runActions_14_0 = null;

        EObject lv_infiniteLoopActions_18_0 = null;

        EObject lv_infiniteLoopActions_20_0 = null;



        	enterRule();

        try {
            // InternalGenerator.g:1311:2: ( ( () otherlv_1= 'RangeControlRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' ) )
            // InternalGenerator.g:1312:2: ( () otherlv_1= 'RangeControlRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            {
            // InternalGenerator.g:1312:2: ( () otherlv_1= 'RangeControlRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}' )
            // InternalGenerator.g:1313:3: () otherlv_1= 'RangeControlRobot' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )? (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )? (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )? otherlv_22= '}'
            {
            // InternalGenerator.g:1313:3: ()
            // InternalGenerator.g:1314:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getRangeControlRobotAccess().getRangeControlRobotAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,49,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getRangeControlRobotAccess().getRangeControlRobotKeyword_1());
            		
            // InternalGenerator.g:1324:3: ( (lv_name_2_0= ruleEString ) )
            // InternalGenerator.g:1325:4: (lv_name_2_0= ruleEString )
            {
            // InternalGenerator.g:1325:4: (lv_name_2_0= ruleEString )
            // InternalGenerator.g:1326:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getRangeControlRobotAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"xtext.robocode.Generator.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_9); 

            			newLeafNode(otherlv_3, grammarAccess.getRangeControlRobotAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalGenerator.g:1347:3: (otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')' )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==18) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalGenerator.g:1348:4: otherlv_4= 'eventsHandled' otherlv_5= '(' ( (lv_eventsHandled_6_0= ruleEvent ) ) (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )* otherlv_9= ')'
                    {
                    otherlv_4=(Token)match(input,18,FOLLOW_10); 

                    				newLeafNode(otherlv_4, grammarAccess.getRangeControlRobotAccess().getEventsHandledKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,19,FOLLOW_11); 

                    				newLeafNode(otherlv_5, grammarAccess.getRangeControlRobotAccess().getLeftParenthesisKeyword_4_1());
                    			
                    // InternalGenerator.g:1356:4: ( (lv_eventsHandled_6_0= ruleEvent ) )
                    // InternalGenerator.g:1357:5: (lv_eventsHandled_6_0= ruleEvent )
                    {
                    // InternalGenerator.g:1357:5: (lv_eventsHandled_6_0= ruleEvent )
                    // InternalGenerator.g:1358:6: lv_eventsHandled_6_0= ruleEvent
                    {

                    						newCompositeNode(grammarAccess.getRangeControlRobotAccess().getEventsHandledEventParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_eventsHandled_6_0=ruleEvent();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    						}
                    						add(
                    							current,
                    							"eventsHandled",
                    							lv_eventsHandled_6_0,
                    							"xtext.robocode.Generator.Event");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1375:4: (otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) ) )*
                    loop34:
                    do {
                        int alt34=2;
                        int LA34_0 = input.LA(1);

                        if ( (LA34_0==15) ) {
                            alt34=1;
                        }


                        switch (alt34) {
                    	case 1 :
                    	    // InternalGenerator.g:1376:5: otherlv_7= ',' ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    {
                    	    otherlv_7=(Token)match(input,15,FOLLOW_11); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getRangeControlRobotAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalGenerator.g:1380:5: ( (lv_eventsHandled_8_0= ruleEvent ) )
                    	    // InternalGenerator.g:1381:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    {
                    	    // InternalGenerator.g:1381:6: (lv_eventsHandled_8_0= ruleEvent )
                    	    // InternalGenerator.g:1382:7: lv_eventsHandled_8_0= ruleEvent
                    	    {

                    	    							newCompositeNode(grammarAccess.getRangeControlRobotAccess().getEventsHandledEventParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_12);
                    	    lv_eventsHandled_8_0=ruleEvent();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"eventsHandled",
                    	    								lv_eventsHandled_8_0,
                    	    								"xtext.robocode.Generator.Event");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop34;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,20,FOLLOW_13); 

                    				newLeafNode(otherlv_9, grammarAccess.getRangeControlRobotAccess().getRightParenthesisKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:1405:3: (otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}' )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==21) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalGenerator.g:1406:4: otherlv_10= 'runActions' otherlv_11= '{' ( (lv_runActions_12_0= ruleAction ) ) (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )* otherlv_15= '}'
                    {
                    otherlv_10=(Token)match(input,21,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getRangeControlRobotAccess().getRunActionsKeyword_5_0());
                    			
                    otherlv_11=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_11, grammarAccess.getRangeControlRobotAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalGenerator.g:1414:4: ( (lv_runActions_12_0= ruleAction ) )
                    // InternalGenerator.g:1415:5: (lv_runActions_12_0= ruleAction )
                    {
                    // InternalGenerator.g:1415:5: (lv_runActions_12_0= ruleAction )
                    // InternalGenerator.g:1416:6: lv_runActions_12_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getRangeControlRobotAccess().getRunActionsActionParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_runActions_12_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    						}
                    						add(
                    							current,
                    							"runActions",
                    							lv_runActions_12_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1433:4: (otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) ) )*
                    loop36:
                    do {
                        int alt36=2;
                        int LA36_0 = input.LA(1);

                        if ( (LA36_0==15) ) {
                            alt36=1;
                        }


                        switch (alt36) {
                    	case 1 :
                    	    // InternalGenerator.g:1434:5: otherlv_13= ',' ( (lv_runActions_14_0= ruleAction ) )
                    	    {
                    	    otherlv_13=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_13, grammarAccess.getRangeControlRobotAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalGenerator.g:1438:5: ( (lv_runActions_14_0= ruleAction ) )
                    	    // InternalGenerator.g:1439:6: (lv_runActions_14_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:1439:6: (lv_runActions_14_0= ruleAction )
                    	    // InternalGenerator.g:1440:7: lv_runActions_14_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getRangeControlRobotAccess().getRunActionsActionParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_runActions_14_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"runActions",
                    	    								lv_runActions_14_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop36;
                        }
                    } while (true);

                    otherlv_15=(Token)match(input,16,FOLLOW_15); 

                    				newLeafNode(otherlv_15, grammarAccess.getRangeControlRobotAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalGenerator.g:1463:3: (otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}' )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==22) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalGenerator.g:1464:4: otherlv_16= 'infiniteLoopActions' otherlv_17= '{' ( (lv_infiniteLoopActions_18_0= ruleAction ) ) (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )* otherlv_21= '}'
                    {
                    otherlv_16=(Token)match(input,22,FOLLOW_3); 

                    				newLeafNode(otherlv_16, grammarAccess.getRangeControlRobotAccess().getInfiniteLoopActionsKeyword_6_0());
                    			
                    otherlv_17=(Token)match(input,13,FOLLOW_14); 

                    				newLeafNode(otherlv_17, grammarAccess.getRangeControlRobotAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGenerator.g:1472:4: ( (lv_infiniteLoopActions_18_0= ruleAction ) )
                    // InternalGenerator.g:1473:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    {
                    // InternalGenerator.g:1473:5: (lv_infiniteLoopActions_18_0= ruleAction )
                    // InternalGenerator.g:1474:6: lv_infiniteLoopActions_18_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getRangeControlRobotAccess().getInfiniteLoopActionsActionParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_infiniteLoopActions_18_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    						}
                    						add(
                    							current,
                    							"infiniteLoopActions",
                    							lv_infiniteLoopActions_18_0,
                    							"xtext.robocode.Generator.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGenerator.g:1491:4: (otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) ) )*
                    loop38:
                    do {
                        int alt38=2;
                        int LA38_0 = input.LA(1);

                        if ( (LA38_0==15) ) {
                            alt38=1;
                        }


                        switch (alt38) {
                    	case 1 :
                    	    // InternalGenerator.g:1492:5: otherlv_19= ',' ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    {
                    	    otherlv_19=(Token)match(input,15,FOLLOW_14); 

                    	    					newLeafNode(otherlv_19, grammarAccess.getRangeControlRobotAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGenerator.g:1496:5: ( (lv_infiniteLoopActions_20_0= ruleAction ) )
                    	    // InternalGenerator.g:1497:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    {
                    	    // InternalGenerator.g:1497:6: (lv_infiniteLoopActions_20_0= ruleAction )
                    	    // InternalGenerator.g:1498:7: lv_infiniteLoopActions_20_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getRangeControlRobotAccess().getInfiniteLoopActionsActionParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_6);
                    	    lv_infiniteLoopActions_20_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getRangeControlRobotRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"infiniteLoopActions",
                    	    								lv_infiniteLoopActions_20_0,
                    	    								"xtext.robocode.Generator.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop38;
                        }
                    } while (true);

                    otherlv_21=(Token)match(input,16,FOLLOW_7); 

                    				newLeafNode(otherlv_21, grammarAccess.getRangeControlRobotAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_22=(Token)match(input,16,FOLLOW_2); 

            			newLeafNode(otherlv_22, grammarAccess.getRangeControlRobotAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRangeControlRobot"


    // $ANTLR start "ruleEventType"
    // InternalGenerator.g:1529:1: ruleEventType returns [Enumerator current=null] : ( (enumLiteral_0= 'BulletHit' ) | (enumLiteral_1= 'BulletMissed' ) | (enumLiteral_2= 'Death' ) | (enumLiteral_3= 'HitByBullet' ) | (enumLiteral_4= 'HitRobot' ) | (enumLiteral_5= 'HitWall' ) | (enumLiteral_6= 'ScannedRobot' ) | (enumLiteral_7= 'Win' ) | (enumLiteral_8= 'Custom' ) ) ;
    public final Enumerator ruleEventType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;
        Token enumLiteral_8=null;


        	enterRule();

        try {
            // InternalGenerator.g:1535:2: ( ( (enumLiteral_0= 'BulletHit' ) | (enumLiteral_1= 'BulletMissed' ) | (enumLiteral_2= 'Death' ) | (enumLiteral_3= 'HitByBullet' ) | (enumLiteral_4= 'HitRobot' ) | (enumLiteral_5= 'HitWall' ) | (enumLiteral_6= 'ScannedRobot' ) | (enumLiteral_7= 'Win' ) | (enumLiteral_8= 'Custom' ) ) )
            // InternalGenerator.g:1536:2: ( (enumLiteral_0= 'BulletHit' ) | (enumLiteral_1= 'BulletMissed' ) | (enumLiteral_2= 'Death' ) | (enumLiteral_3= 'HitByBullet' ) | (enumLiteral_4= 'HitRobot' ) | (enumLiteral_5= 'HitWall' ) | (enumLiteral_6= 'ScannedRobot' ) | (enumLiteral_7= 'Win' ) | (enumLiteral_8= 'Custom' ) )
            {
            // InternalGenerator.g:1536:2: ( (enumLiteral_0= 'BulletHit' ) | (enumLiteral_1= 'BulletMissed' ) | (enumLiteral_2= 'Death' ) | (enumLiteral_3= 'HitByBullet' ) | (enumLiteral_4= 'HitRobot' ) | (enumLiteral_5= 'HitWall' ) | (enumLiteral_6= 'ScannedRobot' ) | (enumLiteral_7= 'Win' ) | (enumLiteral_8= 'Custom' ) )
            int alt40=9;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt40=1;
                }
                break;
            case 51:
                {
                alt40=2;
                }
                break;
            case 52:
                {
                alt40=3;
                }
                break;
            case 53:
                {
                alt40=4;
                }
                break;
            case 54:
                {
                alt40=5;
                }
                break;
            case 55:
                {
                alt40=6;
                }
                break;
            case 56:
                {
                alt40=7;
                }
                break;
            case 57:
                {
                alt40=8;
                }
                break;
            case 58:
                {
                alt40=9;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }

            switch (alt40) {
                case 1 :
                    // InternalGenerator.g:1537:3: (enumLiteral_0= 'BulletHit' )
                    {
                    // InternalGenerator.g:1537:3: (enumLiteral_0= 'BulletHit' )
                    // InternalGenerator.g:1538:4: enumLiteral_0= 'BulletHit'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getBulletHitEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getEventTypeAccess().getBulletHitEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalGenerator.g:1545:3: (enumLiteral_1= 'BulletMissed' )
                    {
                    // InternalGenerator.g:1545:3: (enumLiteral_1= 'BulletMissed' )
                    // InternalGenerator.g:1546:4: enumLiteral_1= 'BulletMissed'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getBulletMissedEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getEventTypeAccess().getBulletMissedEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalGenerator.g:1553:3: (enumLiteral_2= 'Death' )
                    {
                    // InternalGenerator.g:1553:3: (enumLiteral_2= 'Death' )
                    // InternalGenerator.g:1554:4: enumLiteral_2= 'Death'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getDeathEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getEventTypeAccess().getDeathEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalGenerator.g:1561:3: (enumLiteral_3= 'HitByBullet' )
                    {
                    // InternalGenerator.g:1561:3: (enumLiteral_3= 'HitByBullet' )
                    // InternalGenerator.g:1562:4: enumLiteral_3= 'HitByBullet'
                    {
                    enumLiteral_3=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getHitByBulletEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getEventTypeAccess().getHitByBulletEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalGenerator.g:1569:3: (enumLiteral_4= 'HitRobot' )
                    {
                    // InternalGenerator.g:1569:3: (enumLiteral_4= 'HitRobot' )
                    // InternalGenerator.g:1570:4: enumLiteral_4= 'HitRobot'
                    {
                    enumLiteral_4=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getHitRobotEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getEventTypeAccess().getHitRobotEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalGenerator.g:1577:3: (enumLiteral_5= 'HitWall' )
                    {
                    // InternalGenerator.g:1577:3: (enumLiteral_5= 'HitWall' )
                    // InternalGenerator.g:1578:4: enumLiteral_5= 'HitWall'
                    {
                    enumLiteral_5=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getHitWallEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getEventTypeAccess().getHitWallEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalGenerator.g:1585:3: (enumLiteral_6= 'ScannedRobot' )
                    {
                    // InternalGenerator.g:1585:3: (enumLiteral_6= 'ScannedRobot' )
                    // InternalGenerator.g:1586:4: enumLiteral_6= 'ScannedRobot'
                    {
                    enumLiteral_6=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getScannedRobotEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getEventTypeAccess().getScannedRobotEnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalGenerator.g:1593:3: (enumLiteral_7= 'Win' )
                    {
                    // InternalGenerator.g:1593:3: (enumLiteral_7= 'Win' )
                    // InternalGenerator.g:1594:4: enumLiteral_7= 'Win'
                    {
                    enumLiteral_7=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getWinEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getEventTypeAccess().getWinEnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;
                case 9 :
                    // InternalGenerator.g:1601:3: (enumLiteral_8= 'Custom' )
                    {
                    // InternalGenerator.g:1601:3: (enumLiteral_8= 'Custom' )
                    // InternalGenerator.g:1602:4: enumLiteral_8= 'Custom'
                    {
                    enumLiteral_8=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getEventTypeAccess().getCustomEnumLiteralDeclaration_8().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_8, grammarAccess.getEventTypeAccess().getCustomEnumLiteralDeclaration_8());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEventType"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000014000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0003000000020000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000650000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000108000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000610000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000410000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000003010000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x07FC000000000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002010000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000000C000002L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000008000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x00000003C0000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000380000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000C00010000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000000070L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000800010000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000C04000010000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x00003F8000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000C00000010000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000800000010000L});

}