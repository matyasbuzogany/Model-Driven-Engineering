#!/bin/sh
java -cp lib/roborunner-1.2.3.jar:lib/guava-12.0.1.jar:robocodes/r1/libs/robocode.jar robowiki.runner.RoboRunner $*
