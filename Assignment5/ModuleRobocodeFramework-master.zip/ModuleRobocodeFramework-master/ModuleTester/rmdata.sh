rm -rf robocodes/r*/robots/.data

