package jab; 

import jab.gun.*; 
import jab.module.*; 
import jab.module.Module; 
import jab.movement.*; 
import jab.radar.*; 
import jab.selectEnemy.*; 
import jab.targeting.*; 
import java.awt.Color; 

public   class  ModuleBot  extends Module {
	

	protected void initialize() {
		// TODO Customize the colors here
		setBodyColor(Color.RED);
		setGunColor(Color.RED);
		setRadarColor(Color.RED);
		setScanColor(Color.RED);
		setBulletColor(Color.RED);
	}

	

	protected void selectBehavior() {
		radar = selectedRadar;
		movement = selectedMovement;
		targeting = selectedTargeting;
		selectEnemy = selectedSelectEnemy;
		gun = selectedGun;
	}

	
	Radar selectedRadar = new SpinningRadar(this);

	
	Targeting selectedTargeting = new HeadOnTargeting(this);

	
	Movement selectedMovement = new Quiet(this);

	
	SelectEnemy selectedSelectEnemy = new Weakest(this);

	
	Gun selectedGun = new Maximum(this);


}
