package jab;

public class ModuleBot extends Module {
	SelectEnemy selectedSelectEnemy = new Closest(this);
}
