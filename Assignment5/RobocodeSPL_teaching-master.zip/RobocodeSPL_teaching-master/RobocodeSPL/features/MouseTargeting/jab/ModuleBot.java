package jab;

public class ModuleBot extends Module {
	Targeting selectedTargeting = new MouseTargeting(this);
}
