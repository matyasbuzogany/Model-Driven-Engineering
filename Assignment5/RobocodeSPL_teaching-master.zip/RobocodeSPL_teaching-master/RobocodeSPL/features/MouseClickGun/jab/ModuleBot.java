package jab;

public class ModuleBot extends Module {
	Gun selectedGun = new MouseClickGun(this);
}
