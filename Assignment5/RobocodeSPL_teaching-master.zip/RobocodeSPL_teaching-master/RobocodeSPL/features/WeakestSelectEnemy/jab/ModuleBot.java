package jab;

public class ModuleBot extends Module {
	SelectEnemy selectedSelectEnemy = new Weakest(this);
}
