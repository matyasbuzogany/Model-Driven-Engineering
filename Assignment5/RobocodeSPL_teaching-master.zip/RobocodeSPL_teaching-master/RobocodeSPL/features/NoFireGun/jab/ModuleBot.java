package jab;

public class ModuleBot extends Module {
	Gun selectedGun = new CeaseFire(this);
}
