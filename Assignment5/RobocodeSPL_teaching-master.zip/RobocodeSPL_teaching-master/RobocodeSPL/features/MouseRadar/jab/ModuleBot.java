package jab;

public class ModuleBot extends Module {
	Radar selectedRadar = new MouseRadar(this);
}
