package jab;

public class ModuleBot extends Module {
	Targeting selectedTargeting = new HeadOnTargeting(this);
}
