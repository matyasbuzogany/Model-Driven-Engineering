package jab.movement;
import jab.movement.*;
import jab.module.*;


public class WallsMovement extends Movement {
	
	public WallsMovement(Module bot) {
		super(bot);
	}
	
	public void move() {
		if (bot.getHeading() % 90 != 0) {
			bot.setTurnLeft(bot.getHeading() % 90);
		}
		bot.setAhead(Double.POSITIVE_INFINITY);
		if (bot.getVelocity()==0) {
			bot.setTurnRight(90);
		}
	}
	
}
