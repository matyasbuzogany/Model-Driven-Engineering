package jab;

public class ModuleBot extends Module {
	Radar selectedRadar = new WideLockRadar(this);
}
