package jab;

public class ModuleBot extends Module {
	Gun selectedGun = new Maximum(this);
}
