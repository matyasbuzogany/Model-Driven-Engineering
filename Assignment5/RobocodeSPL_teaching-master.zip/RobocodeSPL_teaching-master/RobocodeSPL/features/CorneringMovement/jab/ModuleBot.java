package jab;

public class ModuleBot extends Module {
	Movement selectedMovement = new CorneringMovement(this);
}
